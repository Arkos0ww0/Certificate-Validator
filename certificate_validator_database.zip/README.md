# Certificate Validator Database

## Overview
This database powers the **Certificate Validator project**, managing users, institutions, employers, and certificates with security features like AES, SHA-256, and bcrypt.

## Files
- `schema_only.sql` → schema only (tables + constraints).
- `sample_data.sql` → dummy seed data for testing.
- `certificate_validator_full.sql` → full dump (schema + data).
- `ERD/certificate_validator_ERD.png` → ER diagram (visual).

## Setup Instructions
1. Create the database:
   ```sql
   CREATE DATABASE certificate_validator;
   USE certificate_validator;
   ```
2. Import schema:
   ```bash
   mysql -u root -p certificate_validator < schema_only.sql
   ```
3. Seed dummy data:
   ```bash
   mysql -u root -p certificate_validator < sample_data.sql
   ```

## Security Notes
- Passwords stored with **bcrypt** hashes.
- Certificate metadata encrypted with **AES-256**.
- Certificates fingerprinted with **SHA-256 hashes**.
- `.env` should store DB password + encryption keys (never commit real secrets).

## API Contract
- **Signup:** `{ "name": "...", "email": "...", "password": "...", "role": "student" }`
- **Upload Certificate:** `{ "student_id": 1, "institution_id": 1, "course": "...", "issue_date": "YYYY-MM-DD", "file_content": "base64..." }`

## Backup & Restore
- Backup:  
  ```bash
  mysqldump -u root -p certificate_validator > backup.sql
  ```
- Restore:  
  ```bash
  mysql -u root -p < backup.sql
  ```
